Explanations
============

.. toctree::
   :maxdepth: 3
   :titlesonly:

   platform
   ledger
   plutus-foundation
   rollback
   pab
   order-book-pattern
