# PAB example contracts

This folder contains a couple of contract executables using the examples from `plutus-use-cases`.