{-

Implementation of the wallet's HTTP API using 'MultiWallet'. Effectively acting
as a proxy for the real wallet API implementation.

-}
module Plutus.PAB.Webserver.WalletProxy () where
