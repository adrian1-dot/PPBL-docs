#!/bin/bash
curl -H "Content-Type: application/json" -d @activation.json localhost:9080/api/new/contract/activate