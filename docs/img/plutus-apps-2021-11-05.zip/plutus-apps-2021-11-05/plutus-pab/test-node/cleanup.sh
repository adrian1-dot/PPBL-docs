#!/bin/bash
rm -rf node{1,2}/db node{1,2}/node.sock
