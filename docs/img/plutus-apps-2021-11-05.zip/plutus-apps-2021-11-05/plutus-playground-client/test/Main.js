/*eslint-env node*/
/*global exports require global*/

window = {};
document = {};

require('chartist-plugin-tooltips');
require('chartist-plugin-axistitle');

global = {
    plutusLogo: "PLACEHOLDER"
};

exports.forDeps = function () {};
